<#
.SYNOPSIS
    DOTNExT Context Manager - Manages the Contexts folder system for multi-agent development.

.DESCRIPTION
    This script provides utilities for managing the DOTNExT context continuity system.
    It can initialize the system, create new context folders, show status, and more.

.PARAMETER Action
    The action to perform:
    - init: Initialize the Contexts system (first-time setup)
    - new: Create a new context folder
    - status: Show current context status
    - latest: Show the active context folder path
    - list: List all context folders

.EXAMPLE
    .\Manage-Contexts.ps1 -Action init
    Initializes the Contexts folder system.

.EXAMPLE
    .\Manage-Contexts.ps1 -Action new
    Creates a new context folder with the next sequence number.

.EXAMPLE
    .\Manage-Contexts.ps1 -Action status
    Shows the current context status.

.NOTES
    Author: DOTNExT Project
    Part of the multi-agent development system.
#>

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("init", "new", "status", "latest", "list")]
    [string]$Action
)

# Configuration
$VMRRoot = "D:\Dev\DOTNExT"
$ContextsRoot = "$VMRRoot\Contexts"
$TemplatesRoot = "$VMRRoot\Docs\For AI\contexts-templates"
$Roles = @("SAGE", "BUILD", "DEPLOY", "TEST", "REPO", "CODE")

function Get-LatestContextFolder {
    if (Test-Path "$ContextsRoot\LATEST.txt") {
        $Latest = Get-Content "$ContextsRoot\LATEST.txt" -First 1
        return "$ContextsRoot\$Latest"
    }
    
    # Fallback: find by sorting
    $Folders = Get-ChildItem -Path $ContextsRoot -Directory | 
        Where-Object { $_.Name -match '^\d{3}' } |
        Sort-Object Name -Descending
    
    if ($Folders) {
        return $Folders[0].FullName
    }
    
    return $null
}

function Get-NextSequenceNumber {
    $Folders = Get-ChildItem -Path $ContextsRoot -Directory | 
        Where-Object { $_.Name -match '^\d{3}' } |
        Sort-Object Name -Descending
    
    if ($Folders) {
        $LastNum = [int]($Folders[0].Name.Substring(0, 3))
        return $LastNum + 1
    }
    
    return 1
}

function Initialize-ContextsSystem {
    Write-Host "Initializing DOTNExT Contexts System..." -ForegroundColor Cyan
    Write-Host ""
    
    # Create Contexts folder
    if (-not (Test-Path $ContextsRoot)) {
        New-Item -ItemType Directory -Path $ContextsRoot -Force | Out-Null
        Write-Host "Created: $ContextsRoot" -ForegroundColor Green
    } else {
        Write-Host "Exists: $ContextsRoot" -ForegroundColor Yellow
    }
    
    # Create first context folder
    $FirstContext = "001 - $(Get-Date -Format 'yyyy-MM-dd')"
    $FirstContextPath = "$ContextsRoot\$FirstContext"
    
    if (-not (Test-Path $FirstContextPath)) {
        # Create structure
        foreach ($role in $Roles) {
            New-Item -ItemType Directory -Path "$FirstContextPath\$role" -Force | Out-Null
        }
        New-Item -ItemType Directory -Path "$FirstContextPath\shared" -Force | Out-Null
        
        Write-Host "Created: $FirstContextPath" -ForegroundColor Green
        
        # Initialize STATUS.md
        $StatusTemplate = @"
# Context Status

**Context Folder:** $FirstContext  
**Created:** $(Get-Date -Format 'yyyy-MM-dd HH:mm')  
**Last Updated:** $(Get-Date -Format 'yyyy-MM-dd HH:mm')

---

## Active State

**Current Focus:**  
[Initial setup - define focus]

**Active Roles:**  
[None yet]

**Component States:**
| Component | State | Notes |
|-----------|-------|-------|
| runtime | CLEAN | |
| roslyn | CLEAN | |
| sdk | CLEAN | |

---

## Recent Progress

- $(Get-Date -Format 'yyyy-MM-dd HH:mm') - Context system initialized

---

## Current Blockers

None

---

## Decisions Made

None yet

---

## Next Steps

1. [ ] Define initial focus - Role: Louis - Priority: high
2. [ ] Assign initial roles - Role: Louis - Priority: high

---

*Update this file when significant state changes occur.*
"@
        $StatusTemplate | Out-File -FilePath "$FirstContextPath\STATUS.md" -Encoding UTF8
        Write-Host "Created: STATUS.md" -ForegroundColor Green
        
    } else {
        Write-Host "Exists: $FirstContextPath" -ForegroundColor Yellow
    }
    
    # Create LATEST.txt
    $FirstContext | Out-File -FilePath "$ContextsRoot\LATEST.txt" -Encoding UTF8
    Write-Host "Updated: LATEST.txt -> $FirstContext" -ForegroundColor Green
    
    Write-Host ""
    Write-Host "Contexts system initialized!" -ForegroundColor Cyan
    Write-Host "Active context: $FirstContextPath" -ForegroundColor White
}

function New-ContextFolder {
    Write-Host "Creating new context folder..." -ForegroundColor Cyan
    Write-Host ""
    
    # Check system exists
    if (-not (Test-Path $ContextsRoot)) {
        Write-Host "ERROR: Contexts system not initialized. Run with -Action init first." -ForegroundColor Red
        return
    }
    
    # Get previous context for reference
    $PreviousContext = Get-LatestContextFolder
    
    # Create new folder
    $NextNum = Get-NextSequenceNumber
    $NewFolder = "{0:D3} - {1}" -f $NextNum, (Get-Date -Format 'yyyy-MM-dd')
    $NewPath = "$ContextsRoot\$NewFolder"
    
    # Create structure
    foreach ($role in $Roles) {
        New-Item -ItemType Directory -Path "$NewPath\$role" -Force | Out-Null
    }
    New-Item -ItemType Directory -Path "$NewPath\shared" -Force | Out-Null
    
    Write-Host "Created: $NewPath" -ForegroundColor Green
    
    # Initialize STATUS.md
    $StatusTemplate = @"
# Context Status

**Context Folder:** $NewFolder  
**Created:** $(Get-Date -Format 'yyyy-MM-dd HH:mm')  
**Last Updated:** $(Get-Date -Format 'yyyy-MM-dd HH:mm')  
**Previous Context:** $(Split-Path $PreviousContext -Leaf)

---

## Active State

**Current Focus:**  
[Define focus - carried from previous context?]

**Active Roles:**  
[Define active roles]

**Component States:**
| Component | State | Notes |
|-----------|-------|-------|
| runtime | | Check previous context |
| roslyn | | Check previous context |
| sdk | | Check previous context |

---

## Recent Progress

- $(Get-Date -Format 'yyyy-MM-dd HH:mm') - New context folder created

---

## Current Blockers

[Check previous context for any carried-forward blockers]

---

## Carried Forward from Previous Context

[Review $PreviousContext and note what was carried forward]

---

## Decisions Made

[Carry forward relevant decisions from previous context]

---

## Next Steps

1. [ ] Review previous context folder - Role: [active role] - Priority: high
2. [ ] Define new focus - Role: Louis - Priority: high

---

*Update this file when significant state changes occur.*
"@
    $StatusTemplate | Out-File -FilePath "$NewPath\STATUS.md" -Encoding UTF8
    Write-Host "Created: STATUS.md" -ForegroundColor Green
    
    # Update LATEST.txt
    $NewFolder | Out-File -FilePath "$ContextsRoot\LATEST.txt" -Encoding UTF8
    Write-Host "Updated: LATEST.txt -> $NewFolder" -ForegroundColor Green
    
    Write-Host ""
    Write-Host "New context created!" -ForegroundColor Cyan
    Write-Host "Active context: $NewPath" -ForegroundColor White
    Write-Host ""
    Write-Host "Remember to:" -ForegroundColor Yellow
    Write-Host "  1. Review previous context: $PreviousContext" -ForegroundColor Yellow
    Write-Host "  2. Copy/transcribe relevant information" -ForegroundColor Yellow
    Write-Host "  3. Update STATUS.md with current focus" -ForegroundColor Yellow
}

function Show-ContextStatus {
    Write-Host "DOTNExT Context Status" -ForegroundColor Cyan
    Write-Host "======================" -ForegroundColor Cyan
    Write-Host ""
    
    $LatestPath = Get-LatestContextFolder
    
    if (-not $LatestPath) {
        Write-Host "No context folders found. Run with -Action init to initialize." -ForegroundColor Red
        return
    }
    
    $LatestName = Split-Path $LatestPath -Leaf
    Write-Host "Active Context: $LatestName" -ForegroundColor White
    Write-Host "Path: $LatestPath" -ForegroundColor Gray
    Write-Host ""
    
    # Show STATUS.md summary if exists
    $StatusFile = "$LatestPath\STATUS.md"
    if (Test-Path $StatusFile) {
        Write-Host "STATUS.md exists" -ForegroundColor Green
        
        # Extract key info
        $Content = Get-Content $StatusFile -Raw
        if ($Content -match 'Current Focus:\*\*\s*\r?\n([^\r\n]+)') {
            Write-Host "Focus: $($Matches[1].Trim())" -ForegroundColor White
        }
        if ($Content -match 'Last Updated:\*\*\s*([^\r\n]+)') {
            Write-Host "Last Updated: $($Matches[1].Trim())" -ForegroundColor Gray
        }
    } else {
        Write-Host "STATUS.md missing!" -ForegroundColor Red
    }
    
    Write-Host ""
    Write-Host "Role Folders:" -ForegroundColor White
    foreach ($role in $Roles) {
        $RolePath = "$LatestPath\$role"
        $StateFile = "$RolePath\state.md"
        
        if (Test-Path $StateFile) {
            $ModTime = (Get-Item $StateFile).LastWriteTime.ToString("yyyy-MM-dd HH:mm")
            Write-Host "  $role : state.md exists (modified: $ModTime)" -ForegroundColor Green
        } elseif (Test-Path $RolePath) {
            Write-Host "  $role : folder exists, no state.md" -ForegroundColor Yellow
        } else {
            Write-Host "  $role : missing" -ForegroundColor Red
        }
    }
    
    Write-Host ""
    Write-Host "Shared folder:" -ForegroundColor White
    $SharedPath = "$LatestPath\shared"
    if (Test-Path $SharedPath) {
        $SharedFiles = Get-ChildItem $SharedPath -File
        if ($SharedFiles) {
            foreach ($f in $SharedFiles) {
                Write-Host "  $($f.Name)" -ForegroundColor Gray
            }
        } else {
            Write-Host "  (empty)" -ForegroundColor Gray
        }
    }
}

function Show-LatestContext {
    $LatestPath = Get-LatestContextFolder
    if ($LatestPath) {
        Write-Host $LatestPath
    } else {
        Write-Host "No context folders found." -ForegroundColor Red
    }
}

function Show-ContextList {
    Write-Host "DOTNExT Context Folders" -ForegroundColor Cyan
    Write-Host "=======================" -ForegroundColor Cyan
    Write-Host ""
    
    $Folders = Get-ChildItem -Path $ContextsRoot -Directory | 
        Where-Object { $_.Name -match '^\d{3}' } |
        Sort-Object Name -Descending
    
    $LatestPath = Get-LatestContextFolder
    $LatestName = if ($LatestPath) { Split-Path $LatestPath -Leaf } else { "" }
    
    foreach ($folder in $Folders) {
        $Marker = if ($folder.Name -eq $LatestName) { " <- ACTIVE" } else { "" }
        $StatusExists = if (Test-Path "$($folder.FullName)\STATUS.md") { "[STATUS.md]" } else { "[no status]" }
        Write-Host "$($folder.Name) $StatusExists$Marker" -ForegroundColor $(if ($Marker) { "Green" } else { "White" })
    }
    
    if (-not $Folders) {
        Write-Host "No context folders found." -ForegroundColor Yellow
    }
}

# Main execution
switch ($Action) {
    "init" { Initialize-ContextsSystem }
    "new" { New-ContextFolder }
    "status" { Show-ContextStatus }
    "latest" { Show-LatestContext }
    "list" { Show-ContextList }
}
